#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

# Adapted from https://github.com/kyamagu/bbox-annotator/
# Edited original JS to add color_list as an option
# ...should be the same length as labels
# ...and controls the color of the rectangle
# ...will probably be broken for input_method = "fixed" or "text"
# Also added color as a value in each rectangle entry

js <- '
    $(document).ready(function() {
       // define options to pass to bounding box constructor
        var options = {
          url: "https://www.dropbox.com/s/s8vh1wdpok15lz5/worm.PNG?raw=1",
          input_method: "select", 
          labels: [""],
          color_list:  [""], 
          onchange: function(entries) {
                Shiny.onInputChange("rectCoord", JSON.stringify(entries, null, "  "));
          }
        };

        // Initialize the bounding-box annotator.
        var annotator = new BBoxAnnotator(options);

        // Initialize the reset button.
        $("#reset_button").click(function(e) {
            annotator.clear_all();
        })

        // define function to reset the bbox
        // ...upon choosing new label category or new url
        function reset_bbox(options) {
          document.getElementById("bbox_annotator").setAttribute("style", "display:inline-block");
          $(".image_frame").remove();
          annotator = new BBoxAnnotator(options);
        }

        // update image url from shiny
        Shiny.addCustomMessageHandler("change-img-url", function(url) {
          options.url = url;
          options.width = null;
          options.height = null;
          reset_bbox(options);
        });

        // update colors and categories from shiny
        Shiny.addCustomMessageHandler("update-category-list", function(vals) {
          options.labels = Object.values(vals);
          options.color_list = Object.keys(vals);
          reset_bbox(options);
        });
        
        //update list from CSV
        Shiny.addCustomMessageHandler("rectCoord", function(value) {
          Shiny.setInputValue("rectCoord", value);
            });
        
        
        // redraw rectangles based on list of entries
        Shiny.addCustomMessageHandler("redraw-rects", function(vals) {
          var arr = JSON.parse(vals)
          arr.forEach(function(rect){
             annotator.add_entry(rect);
          });
          if (annotator.onchange) {
             annotator.onchange(annotator.entries);
          }
        }); 
    });
'





library(shiny)
library(tidyverse)
library(ggplot2)
library(magrittr)
library(survminer)
library(survival)
library(openxlsx)
library(rdrop2)
library(jsonlite)
library(stringr)

token <- readRDS("C:/wormbot_app/droptoken.rds")
drop_auth(rdstoken = "C:/wormbot_app/droptoken.rds")

drop_imgdir <- "/wormbot_data/image_series1/" 
drop_csvdir <- "/wormbot_data/csv_files_series1/"  
drop_csvdirdone <- "/wormbot_data/finished_csv_files/" 

round_df <- function(x, digits) {
    # round all numeric variables
    # x: data frame 
    # digits: number of digits to round
    numeric_columns <- sapply(x, mode) == 'numeric'
    x[numeric_columns] <-  round(x[numeric_columns], digits)
    x
}


#define the UI 
ui <- fluidPage(
    tags$head(tags$script(HTML(js)),
              tags$head(
                  tags$script(src = "bbox_annotation.js")
              )),
    titlePanel("Neural Network Training"),
    sidebarLayout(
        sidebarPanel(
            actionButton("load", "Load Images"),
            sliderInput("slider", "Select Frame:", min = 1, max = 7, value = 1), 
            actionButton("done", "Finish Session"),
            
            selectInput("category_type", "Label Category", c("worms", "geography")),
            div(HTML(
                '<input id="reset_button" type="reset" />'
            )),
            HTML(
                '<input id="annotation_data" name="annotation_data" type="hidden" />'
            ),
            hr(),
            h4("Entries"),
            verbatimTextOutput("rectCoordOutput")
            
        ),
        mainPanel(div(id = "bbox_annotator", style = "display:inline-block"))
    )
)


# ui structure 

#load button
#slider value 
    #reactive val which is updated to the frame number 

#done button 



#if load button is pressed 
#load up the csv file of all the image links AS DATA FRAME 

links_file <- drop_read_csv(drop_imgdir, header = FALSE, dest = tempdir(), dtoken = token)

#load up the csv file of annotations AS DATA FRAME 
#csvNewName <- gsub(".png","_NN.csv",imageName)

#loads in the csv file (making the global csv)

list_files <- drop_dir(drop_csvdir, dtoken = token)
for (k in 1:dim(list_files)[1]){
    new_data <- drop_read_csv(list_files$path_lower[k],dtoken = token)
    #index is a new column created in the new data row, has been added to the 
    #global csv file
    new_data$index <- k
    if (k == 1){
        totalFiles <- new_data
    }
    else {
        totalFiles <- rbind(totalFiles,new_data)
    }
}

#if slider frame is changed 
#update the reactive val
imageonlyworms <- totalFiles %>% filter(index == REACTIVEVAL) %>% select(-index)
     
#pull that row from the image link data frame 
#load the image 
#send image to display 


fileURL <- links_file[imgNum,2]
realULRcorr <- gsub("dl=0","raw=1", fileURL)
session$sendCustomMessage("change-img-url", realULRcorr)


    #convert image only worms to javascript format 
    #send boxes using bbox annotator 
new_data <- drop_read_csv(dropcsvPath, dtoken = token)
new_data1<-subset(new_data,select=-c(dataCells1,dataCells2))
new_data1 <- round_df(new_data1,0)
new_data2 <- new_data1

data_as_char <- 1:num_of_rows
as.character(data_as_char)
new_data2$F <- data_as_char
new_data2$G <- "yellow"
colLabels <- c("left","top","width","height","label","color")
colnames(new_data2) <- colLabels
jsonfile <- toJSON(new_data2,pretty=TRUE)
jsonfile2 <- str_replace_all(jsonfile, "[\r\n]" , "\n")

#send message to load pre-annotted bounding boxes into the annotater program
session$sendCustomMessage("redraw-rects", jsonfile2)


#if slider frame is changed again 
    # update the annotation data with the new boxes 
    # replace that row in data frame with the new annotation data 
    # update the reactive val 
    # pull that row from the image link csv file
    # load the image


# if done button is pressed 
    # overwrite the original annotation csv with the data from the 
    # updated data frame 


    
    